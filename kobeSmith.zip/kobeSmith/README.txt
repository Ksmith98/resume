*Notes / Reviews / Comments

[Notes]
-The workflow of working from Indesign > Code was very fluid and helpful, however I had found that certain properties and characteristics that worked 
best on an 8 1/2 x 11 in paper were not as eefective visually in a browser. If I were to re-do my resume, I would incorporate some better optomization 
techniques for web in my initial ideas and drafts. 

*Issues}
	-Wasted Code? D.R.Y?
	-Broke responsiveness with Flexbox
	-Spacing, Padding, Fixing Text Hierarchy, etc. 